<template>
	<view class="position-fixed bottom-0 left-0 right-0 d-flex a-stretch bg-white" 
	style="height: 100upx;z-index: 100;">
		<view class="flex-1 d-flex flex-column a-center j-center line-h-md">
			<view class="icon iconfont icon-xihuan text-light-muted line-h font-md"></view>
			收藏
		</view>
		<view class="flex-1 d-flex flex-column a-center j-center line-h-md">
			<view class="icon iconfont icon-gouwuche text-light-muted line-h font-md"></view>
			购物车
		</view>
		<view class="d-flex flex-column a-center j-center main-bg-color text-white font-md shadow" 
		hover-class="main-bg-hover-color"
		style="flex: 2.5;">加入购物车</view>
	</view>
</template>

<script>
</script>

<style>
</style>
