<template>
	<view class="d-flex py-5 a-center j-center animated fadeIn faster ">
		<view class="icon iconfont icon-gouwuche text-light-muted"
		style="font-size: 50upx;"></view>
		<text class="text-light-muted mx-2">购物车还是空的</text>
		<view class="border px-2 py-1 rounded"
		hover-class="bg-light-secondary">去逛逛</view>
	</view>
</template>

<script>
</script>

<style>
</style>
