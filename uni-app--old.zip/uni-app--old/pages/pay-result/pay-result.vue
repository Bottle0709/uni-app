<template>
	<view>
		
		<view class="d-flex flex-column a-center j-center py-5 my-3">
			<text class="iconfont icon-iconfontxuanzhong4 main-text-color line-h" style="font-size: 180rpx;"></text>
			<text class="text-dark font-lg line-h-sm">支付成功</text>
		</view>
		<view class="px-5">
			<view class="rounded main-bg-color text-white font-md w-100 py-2 mt-3 text-center" hover-class="main-bg-hover-color"
			@click="openDetail">
				查看订单
			</view>
			<view class="rounded border font-md w-100 py-2 mt-3 text-center" hover-class="bg-light" @click="openIndex">
				返回首页
			</view>
		</view>
		
		
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			}
		},
		methods: {
			openDetail(){
				uni.navigateBack({
					delta: 1
				});
			},
			openIndex(){
				uni.switchTab({
					url:"/pages/index/index"
				})
			}
		}
	}
</script>

<style>

</style>
